#!/bin/bash
DATA=/path/to/GBS_data.fastq
BARCODE=/path/to/barcode
TOOL=path/to/sabre/sabre
exec &> sabre.log

$TOOL se -f $DATA -b $BARCODE -u unk.fastq
