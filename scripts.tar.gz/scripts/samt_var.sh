#!/bin/bash


DATA=/path/to/bamlist
REF=/path/to/refgenome/Gmax_275_v2.0.fa
OUT=variantcalling

mkdir results1

exec &> samt_var.log

bcftools mpileup -g -f $REF -b $DATA > ./results1/variants.bcf

	if [ $? -ne 0 ]
                        then
                                printf "There is a problem at the bcftools_mpileup step"
                                exit 1
                fi


bcftools call -mv ./results1/variants.bcf > ./results1/variants.vcf

	if [ $? -ne 0 ]
                        then
                                printf "There is a problem at the bcf2vcf step"
                                exit 1
                fi
